extern const float gaussian_k[25];

extern const int gaussian_w;
extern const int gaussian_h;
