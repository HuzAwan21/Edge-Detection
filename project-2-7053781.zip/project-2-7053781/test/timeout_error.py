class TimeoutError(Exception):
    pass
